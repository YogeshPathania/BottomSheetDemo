package com.example.bottomsheetdemo

import android.databinding.DataBindingUtil
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.bottomsheetdemo.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var mbinding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mbinding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        mbinding.sheet.setOnClickListener {

            val fragment = BottomSheet()
            fragment.show(supportFragmentManager, fragment.tag)


        }


    }
}
//.................bottom sheeet...........................//
class BottomSheet : BottomSheetFragment() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mbinding=

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


    }



}
//step 1. add the dependency of material
//step 2. set the theme for the bottom sheet in styles
//step 3. create the seprate class that extends the bottomsheetFragments
//step 4. override the two function....
//1. get theme()
//2. onCreateDialog()

//step 5.set the code on click that we set the seprate class of bottom sheet and set the layout
//and set fragment support manager in class
// step 6. extend the : BottomSheetFragment() in the new class

// step 7. new classis created  overide the fragment two methods
// 1. on create
// 2. on view created


